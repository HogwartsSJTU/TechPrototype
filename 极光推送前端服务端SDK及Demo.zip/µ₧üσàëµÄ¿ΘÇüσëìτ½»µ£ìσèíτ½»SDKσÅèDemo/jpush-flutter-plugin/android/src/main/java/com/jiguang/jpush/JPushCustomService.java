package com.jiguang.jpush;

import cn.jpush.android.service.JCommonService;

public class JPushCustomService extends JCommonService {
}
