/**
 * Examples for demo API usage. 
 */
package cn.jpush.api.examples;