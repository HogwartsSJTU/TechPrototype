package cn.jpush.api.schedule.model;

import com.google.gson.JsonElement;

public interface IModel {

    public JsonElement toJSON();
}
