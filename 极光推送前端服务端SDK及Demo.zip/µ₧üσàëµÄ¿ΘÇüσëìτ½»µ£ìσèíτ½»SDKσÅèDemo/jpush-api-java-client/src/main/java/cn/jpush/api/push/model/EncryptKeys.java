package cn.jpush.api.push.model;

public class EncryptKeys {

    public static String ENCRYPT_SMS2_TYPE = "SM2";
    public static String DEFAULT_SM2_ENCRYPT_KEY = "BPj6Mj/T444gxPaHc6CDCizMRp4pEl14WI2lvIbdEK2c+5XiSqmQt2TQc8hMMZqfxcDqUNQW95puAfQx1asv3rU=";

}
