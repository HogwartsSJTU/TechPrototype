/**
 * Schedule API features.
 *
 * Url: https://api.jpush.cn/v3/schedules
 */
package cn.jpush.api.schedule;