package cn.jpush.api;

public interface FastTests {

}
